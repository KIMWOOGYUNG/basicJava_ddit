package snackbar;

import java.util.Scanner;

import vo.SnackCartVO;
import vo.SnackCategoryVO;
import vo.SnackVO;
import controller.Controller;
import dao.SnackCartDAO;
import dao.SnackCategoryDAO;
import dao.SnackDAO;
import data.Session;

//스낵바 구매
public class SnackBar {
	// 직원 -> 스낵추가 가능(삭제)

	int input;
	Scanner s = new Scanner(System.in);

	// 스낵
	SnackVO snackVO = new SnackVO();
	SnackDAO snackDAO = SnackDAO.getInstance();

	// 스낵종류
	SnackCategoryVO snackCategoryVO = new SnackCategoryVO();
	SnackCategoryDAO snackCategoryDAO = dao.SnackCategoryDAO.getInstance();

	// 스낵장바구니
	SnackCartVO snackCartVO = new SnackCartVO();
	SnackCartDAO snackCartDAO = SnackCartDAO.getInstance();

	int snackCartNum = 0;
	
	// 스낵초기화면
	public void snackBar() {
		//카트 생성
		SnackCartVO snackCartVO = new SnackCartVO();
		snackCartNum++;
		snackCartVO.setSnackCartNum(snackCartNum); // 장바구니 1번
		snackCartVO.setUserId(Session.loginUser.getUserId()); //회원아이디 불러오기
		snackCartVO.setSnackCount(0); // 
		snackCartVO.setSnackNum(0); // 
		snackCartVO.setPaymentNum(-1); // 결제 전 초기값 -1
		
		System.out.println("------------------------------------");
		System.out.println("1. 팝콘 주문");
		System.out.println("2. 음료 주문");
		System.out.println("3. 스낵류 주문");
		System.out.println("4. CGB 콤보");
		System.out.println("5. 장바구니로 이동");
		System.out.println("0. 초기 화면으로");
		System.out.println("------------------------------------");
		input = Integer.parseInt(s.nextLine());

		switch (input) {
		case 1:
			popcornMenu();
			break;

		case 2:
			drinkMenu();
			break;

		case 3:
			snackMenu();
			break;

		case 4:
			setMenu();
			break;

		case 5:
			snackCartDAO.selectSnackCartList();
			break;

		case 0:
			Controller.menu_start();
			break;

		default:
			System.out.println("잘못 입력하셨습니다. 다시 시도해주세요.");
		}

	}
	
//------------------------------------------------------------------------------------------

	// 팝콘메뉴
	public void popcornMenu() {

		System.out.println("------------------------------------");
		// 고소팝콘, 달콤팝콘 등을 snackVO에서 들고와 출력해서 보여줌
		for (int i = 0; i < snackDAO.selectSnackList().size(); i++) {
			if (snackDAO.selectSnackList().get(i).getSnackCategoryNum() == 0) {
				System.out.println(snackDAO.selectSnackList().get(i)
						.getSnackNum()
						+ ". "
						+ snackDAO.selectSnackList().get(i).getSnackName()
						+ " : "
						+ snackDAO.selectSnackList().get(i).getSnackPrice());
			}
		}
		System.out.println("9. 스낵바 초기 화면으로");
		System.out.println("0. 초기 화면으로");
		System.out.println("------------------------------------");
		System.out.println("다음 해당번호를 입력해주세요>");

		int input = 0;
		int popcornCount = 0;

		input = Integer.parseInt(s.nextLine());

		if (input == 9) {
			snackBar();
		} else if (input == 0) {
			Controller.menu_start();
		} else if (input > 10) {
			System.out.println("잘못입력하셨습니다. 다시 입력해주세요.");
			popcornMenu();
		}
		

		int SnackCartListSize = snackCartDAO.selectSnackCartList().size();
		int newPopcornNum = input - 1; //리스트상 메뉴번호

		// 장바구니가 비었을때
		if (SnackCartListSize == 0) {
			snackCartVO.setSnackNum(newPopcornNum);
			snackCartVO.setSnackCount(1); // 기본수량 1개
			snackCartDAO.insertSnackCart(snackCartVO);

			// 장바구니에 상품이 한개이상 담겨있을때
		} else {
			for (int i = 0; i < SnackCartListSize; i++) {

				// 같은 스낵번호의 상품이 이미 담겨있을 경우
				if (newPopcornNum == snackCartDAO.selectSnackCartList().get(i)
						.getSnackNum()) {
					popcornCount = snackCartDAO.selectSnackCartList().get(i)
							.getSnackCount();
					popcornCount++;
					snackCartDAO.selectSnackCartList().get(i)
							.setSnackCount(popcornCount);

					// 카운트 플러스 됐는지 확인
					System.out.println(snackCartDAO.selectSnackCartList()
							.get(i).getSnackNum());
					
					System.out.println(snackCartDAO.selectSnackCartList()
							.get(i).getSnackCount());
					System.out.println("장바구니에 있었음");
					break;
				}

				// 목록을 조회하다 마지막까지도 같은 이름이 없으면 장바구니에 새로 저장하기
				if (i == SnackCartListSize - 1) { // 마지막리스트
					SnackCartVO snackCartVO = new SnackCartVO();
					snackCartVO.setSnackNum(newPopcornNum); //실제 메뉴번호를 저장함
					snackCartVO.setSnackCount(1);
					snackCartDAO.insertSnackCart(snackCartVO);
					System.out.println("장바구니에 없었음");
					break;
				}

			}
		}

		// 현재까지 담긴 장바구니 목록 출력
		System.out.println();
		System.out.println("---------장바구니목록----------");
		for (int i = 0; i < snackCartDAO.selectSnackCartList().size(); i++) {
			System.out.println(snackCartDAO.selectSnackCartList().get(i)
					.getSnackNum()
					+ 1
					+ "번 "
					+ snackDAO
							.selectSnackList()
							.get(snackCartDAO.selectSnackCartList().get(i)
									.getSnackNum()).getSnackName()
					+ " "
					+ snackCartDAO.selectSnackCartList().get(i).getSnackCount()
					+ "개");
		}
		additionalOrder();

	}
	
//------------------------------------------------------------------------------------------
	
	// 음료메뉴
	public void drinkMenu() {

		System.out.println("------------------------------------");
		for (int i = 0; i < snackDAO.selectSnackList().size(); i++) {
			if (snackDAO.selectSnackList().get(i).getSnackCategoryNum() == 1) {
				System.out.println(snackDAO.selectSnackList().get(i)
						.getSnackNum()
						+ ". "
						+ snackDAO.selectSnackList().get(i).getSnackName()
						+ " : "
						+ snackDAO.selectSnackList().get(i).getSnackPrice());
			}
		}
		System.out.println("9. 스낵바 초기 화면으로");
		System.out.println("0. 초기 화면으로");
		System.out.println("------------------------------------");
		System.out.println("다음 해당번호를 입력해주세요>");

		int input = 0;
		int drinkCount = 0;

		input = Integer.parseInt(s.nextLine());

		if (input == 9) {
			snackBar();
		} else if (input == 0) {
			Controller.menu_start();
		} else if (input > 23 || input < 9) {
			System.out.println("잘못입력하셨습니다. 다시 입력해주세요.");
			drinkMenu();
		}

		int SnackCartListSize = snackCartDAO.selectSnackCartList().size();
		int newDrinkNum = input - 2;

		// 장바구니가 비었을때
		if (SnackCartListSize == 0) {
			snackCartVO.setSnackNum(newDrinkNum); // 스낵번호 스낵vo에서 가져옴
			snackCartVO.setSnackCount(1); // 기본수량 1개
			snackCartDAO.insertSnackCart(snackCartVO);

			// 장바구니에 상품이 한개이상 담겨있을때
		} else {
			for (int i = 0; i < SnackCartListSize; i++) {

				// 같은 스낵번호의 상품이 이미 담겨있을 경우
				if (newDrinkNum == snackCartDAO.selectSnackCartList().get(i)
						.getSnackNum()) {
					drinkCount = snackCartDAO.selectSnackCartList().get(i)
							.getSnackCount();
					drinkCount++;
					snackCartDAO.selectSnackCartList().get(i)
							.setSnackCount(drinkCount);

					// 카운트 플러스 됐는지 확인
					System.out.println(snackCartDAO.selectSnackCartList()
							.get(i).getSnackNum());
					System.out.println(snackCartDAO.selectSnackCartList()
							.get(i).getSnackCount());
					System.out.println("장바구니에 있었음");
					break;
				}

				// 목록을 조회하다 마지막까지도 같은 이름이 없으면 장바구니에 새로 저장하기
				if (i == SnackCartListSize - 1) { // 마지막리스트
					SnackCartVO snackCartVO = new SnackCartVO();
					snackCartVO.setSnackNum(newDrinkNum);
					snackCartVO.setSnackCount(1);
					snackCartDAO.insertSnackCart(snackCartVO);
					System.out.println("장바구니에 없었음");
					break;
				}

			}
		}

		// 현재까지 담긴 장바구니 목록 출력
		System.out.println();
		System.out.println("---------장바구니목록----------");
		for (int i = 0; i < snackCartDAO.selectSnackCartList().size(); i++) {
			System.out.println(snackCartDAO.selectSnackCartList().get(i)
					.getSnackNum()
					+ 2
					+ "번 "
					+ snackDAO
							.selectSnackList()
							.get(snackCartDAO.selectSnackCartList().get(i)
									.getSnackNum()).getSnackName()
					+ " "
					+ snackCartDAO.selectSnackCartList().get(i).getSnackCount()
					+ "개");
		}

		additionalOrder();

	}

//------------------------------------------------------------------------------------------	
	
	// 스낵메뉴

	public void snackMenu() {

		System.out.println("------------------------------------");
		for (int i = 0; i < snackDAO.selectSnackList().size(); i++) {
			if (snackDAO.selectSnackList().get(i).getSnackCategoryNum() == 2) {
				System.out.println(snackDAO.selectSnackList().get(i)
						.getSnackNum()
						+ ". "
						+ snackDAO.selectSnackList().get(i).getSnackName()
						+ " : "
						+ snackDAO.selectSnackList().get(i).getSnackPrice());
			}
		}
		System.out.println("9. 스낵바 초기 화면으로");
		System.out.println("0. 초기 화면으로");
		System.out.println("------------------------------------");
		System.out.println("다음 해당번호를 입력해주세요>");

		int input = 0;
		int snackCount = 0;

		input = Integer.parseInt(s.nextLine());

		if (input == 9) {
			snackBar();
		} else if (input == 0) {
			Controller.menu_start();
		} else if (input > 28 || input < 24) {
			System.out.println("잘못입력하셨습니다. 다시 입력해주세요.");
			snackMenu();
		}

		int SnackCartListSize = snackCartDAO.selectSnackCartList().size();
		int newSnackNum = input - 2;

		// 장바구니가 비었을때
		if (SnackCartListSize == 0) {
			snackCartVO.setSnackNum(newSnackNum); // 스낵번호 스낵vo에서 가져옴
			snackCartVO.setSnackCount(1); // 기본수량 1개
			snackCartDAO.insertSnackCart(snackCartVO);

			// 장바구니에 상품이 한개이상 담겨있을때
		} else {
			for (int i = 0; i < SnackCartListSize; i++) {

				// 같은 스낵번호의 상품이 이미 담겨있을 경우
				if (newSnackNum == snackCartDAO.selectSnackCartList().get(i)
						.getSnackNum()) {
					snackCount = snackCartDAO.selectSnackCartList().get(i)
							.getSnackCount();
					snackCount++;
					snackCartDAO.selectSnackCartList().get(i)
							.setSnackCount(snackCount);

					// 카운트 플러스 됐는지 확인
					System.out.println(snackCartDAO.selectSnackCartList()
							.get(i).getSnackNum());
					System.out.println(snackCartDAO.selectSnackCartList()
							.get(i).getSnackCount());
					System.out.println("장바구니에 있었음");
					break;
				}

				// 목록을 조회하다 마지막까지도 같은 이름이 없으면 장바구니에 새로 저장하기
				if (i == SnackCartListSize - 1) { // 마지막리스트
					SnackCartVO snackCartVO = new SnackCartVO();
					snackCartVO.setSnackNum(newSnackNum);
					snackCartVO.setSnackCount(1);
					snackCartDAO.insertSnackCart(snackCartVO);
					System.out.println("장바구니에 없었음");
					break;
				}

			}
		}

		// 현재까지 담긴 장바구니 목록 출력
		System.out.println();
		System.out.println("---------장바구니목록----------");
		for (int i = 0; i < snackCartDAO.selectSnackCartList().size(); i++) {
			System.out.println(snackCartDAO.selectSnackCartList().get(i)
					.getSnackNum()
					+ 2
					+ "번 "
					+ snackDAO
							.selectSnackList()
							.get(snackCartDAO.selectSnackCartList().get(i)
									.getSnackNum()).getSnackName()
					+ " "
					+ snackCartDAO.selectSnackCartList().get(i).getSnackCount()
					+ "개");
		}

		additionalOrder();

	}

//------------------------------------------------------------------------------------------
	
	// 세트메뉴

	public void setMenu() {

		System.out.println("------------------------------------");
		for (int i = 0; i < snackDAO.selectSnackList().size(); i++) {
			if (snackDAO.selectSnackList().get(i).getSnackCategoryNum() == 3) {
				System.out.println(snackDAO.selectSnackList().get(i)
						.getSnackNum()
						+ ". "
						+ snackDAO.selectSnackList().get(i).getSnackName()
						+ " : "
						+ snackDAO.selectSnackList().get(i).getSnackPrice());
			}
		}
		System.out.println("9. 스낵바 초기 화면으로");
		System.out.println("0. 초기 화면으로");
		System.out.println("------------------------------------");
		System.out.println("다음 해당번호를 입력해주세요>");

		int input;
		int setMenuCount;

		input = Integer.parseInt(s.nextLine());

		if (input == 9) {
			snackBar();
		} else if (input == 0) {
			Controller.menu_start();
		} else if (input > 32 || input < 29) {
			System.out.println("잘못입력하셨습니다. 다시 입력해주세요.");
			setMenu();
		}

		int SnackCartListSize = snackCartDAO.selectSnackCartList().size();
		int newSetMenuNum = input - 2;

		// 장바구니가 비었을때
		if (SnackCartListSize == 0) {
			snackCartVO.setSnackNum(newSetMenuNum); // 스낵번호 스낵vo에서 가져옴
			snackCartVO.setSnackCount(1); // 기본수량 1개
			snackCartDAO.insertSnackCart(snackCartVO);

			// 장바구니에 상품이 한개이상 담겨있을때
		} else {
			for (int i = 0; i < SnackCartListSize; i++) {

				// 같은 스낵번호의 상품이 이미 담겨있을 경우
				if (newSetMenuNum == snackCartDAO.selectSnackCartList().get(i)
						.getSnackNum()) {
					setMenuCount = snackCartDAO.selectSnackCartList().get(i)
							.getSnackCount();
					setMenuCount++;
					snackCartDAO.selectSnackCartList().get(i)
							.setSnackCount(setMenuCount);

					// 카운트 플러스 됐는지 확인
					System.out.println(snackCartDAO.selectSnackCartList()
							.get(i).getSnackNum());
					System.out.println(snackCartDAO.selectSnackCartList()
							.get(i).getSnackCount());
					System.out.println("장바구니에 있었음");
					break;
				}

				// 목록을 조회하다 마지막까지도 같은 이름이 없으면 장바구니에 새로 저장하기
				if (i == SnackCartListSize - 1) { // 마지막리스트
					SnackCartVO snackCartVO = new SnackCartVO();
					snackCartVO.setSnackNum(newSetMenuNum);
					snackCartVO.setSnackCount(1);
					snackCartDAO.insertSnackCart(snackCartVO);
					System.out.println("장바구니에 없었음");
					break;
				}

			}
		}

		// 현재까지 담긴 장바구니 목록 출력
		System.out.println();
		System.out.println("---------장바구니목록----------");
		for (int i = 0; i < snackCartDAO.selectSnackCartList().size(); i++) {
			System.out.println(snackCartDAO.selectSnackCartList().get(i)
					.getSnackNum()
					+ 2
					+ "번 스낵 "
					+ snackDAO
							.selectSnackList()
							.get(snackCartDAO.selectSnackCartList().get(i)
									.getSnackNum()).getSnackName()
					+ " "
					+ snackCartDAO.selectSnackCartList().get(i).getSnackCount()
					+ "개");
		}

		additionalOrder();

	}

//------------------------------------------------------------------------------------------
	
	// 추가주문

	public void additionalOrder() {
		System.out.println("------------------------------------");
		System.out.println("1. 팝콘을 더 주문하시겠습니까?");
		System.out.println("2. 음료를 더 주문하시겠습니까?");
		System.out.println("3. 스낵류를 더 주문하시겠습니까?");
		System.out.println("4. 세트메뉴를 더 주문하시겠습니까?");
		System.out.println("5. 담은 스낵 확인하기");
		System.out.println("6. 장바구니로 이동");
		System.out.println("------------------------------------");
		input = Integer.parseInt(s.nextLine());

		switch (input) {
		case 1:
			popcornMenu();
			break;
		case 2:
			drinkMenu();
			break;
		case 3:
			snackMenu();
			break;
		case 4:
			setMenu();
			break;
		case 5:
			for (int i = 0; i < snackCartDAO.selectSnackCartList().size(); i++) {
				System.out.println(snackCartDAO.selectSnackCartList().get(i)
						.getSnackNum()
						+ "번 스낵 "
						+ snackCartDAO.selectSnackCartList().get(i)
								.getSnackCount());
			}
		}
		//case 6: cart.cart(); break;

	}

}
